open cmd with admin privileges 
change directory with: 
	cd "to-this-extracted-folder-path"
install service with:
	killmihoyo.exe install start